part of appwrite.models;

abstract class Model {
  Map<String, dynamic> toMap();
}
