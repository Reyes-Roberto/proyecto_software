import 'package:flutter/material.dart';

const appName = 'Ai App';

late Size mq;

String apiKey = '';