package com.example.ai_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
